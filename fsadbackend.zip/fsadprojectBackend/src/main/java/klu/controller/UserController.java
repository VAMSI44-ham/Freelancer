package klu.controller;

import klu.model.User;
import klu.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173") // or your React port
public class UserController {

    @Autowired
    private UserRepository userRepository;

    // Existing: GET all users
    @GetMapping
    public List<User> getUsers() {
        return userRepository.findAll();
    }

    // ✅ Signup
    @PostMapping("/signup")
    public User signup(@RequestBody User user) {
        return userRepository.save(user); // saves to DB
    }

    // ✅ Login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String password = credentials.get("password");

        User user = userRepository.findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }
}
